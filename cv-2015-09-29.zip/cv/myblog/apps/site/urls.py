from django.conf.urls import patterns, url


from apps.site import views

urlpatterns = patterns('',
    url(r'^about$', views.AboutPage.as_view(), name='about'),
    url(r'^cv$', views.CvPage.as_view(), name='cv'),
    url(r'^contact/$', 'apps.site.views.contact'),
    url(r'^thanks_contact/$', 'apps.site.views.thanks_contact'),
    url(r'^$', views.HomePage.as_view(), name='home'),
    
)
