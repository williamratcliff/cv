# top-level views for the project, which don't belong in any specific app

import datetime,time
import logging
import sys, os,pytz
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.shortcuts import render_to_response, render
from django.conf import settings


from django.views.generic.base import TemplateView
from django import forms
from models import ContactForm
from django.views.decorators.csrf import csrf_exempt,csrf_protect#,csrf_response_exempt,csrf_view_exempt
from django.core.urlresolvers import reverse
from django.core.mail import send_mail, EmailMessage
from django.views.generic import list_detail
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import User
from django.template import RequestContext


class HomePage(TemplateView):

    template_name = "index.html"

class AboutPage(TemplateView):
    template_name = "about.html"

class CvPage(TemplateView):
    template_name = "cv.html"
    
    

def send_contact(cd):
    subject='Contact form regarding %s'%(cd['subject'],)
    message='Thank you for comment.'
    #keys=['name', 'email','subject','comment']
    message2=''
    print 'reached'
    for key in cd.keys():
        message2=message2+"%s:%s\n"%(key,cd[key],)
    print 'message2', message2
    sender=settings.EMAIL_HOST_USER
    sender=cd['email']
    print 'message2'
    print message2
    print 'sending'
    recipient_list=[cd['email']]

    try:
        #send_mail(subject, message, sender, recipient_list) # send a note to the applicant
        #print 'applicant sent'  #Should we send things to the person?
        #send_mail(cd['email'],message2,sender,[sender])
        send_mail(subject,message2,sender,['support@williamratcliff.com'])
        print 'organizer sent'
    except:
        print 'failed to send'
    return		

    
def thanks_contact(request):
    return render_to_response("thanks_contact.html",{'user':request.user,
                                                     'request':request,},
                              context_instance=RequestContext(request))

@csrf_exempt
def contact(request):
    if request.method== 'POST':
        print 'reached start'
        form=ContactForm(request.POST)#, initial={'rank_status':'STUDENT', 'preferred_housing':'DORM'})
        if form.is_valid():
            cd=form.cleaned_data
            print 'valid'
            print 'user', request.user
            print 'cd', cd
            try:
                subject=cd['subject']
                email=cd['email']
                name=cd['name']
                comments=cd['comments']
                send_contact(cd)
            except:
                pass
                #they didn't agree
            #gen_session(cd,request.user)
            return HttpResponseRedirect('/thanks_contact')
    else:
        print 'invalid or not used'
        form=ContactForm()
        #initial={'rank_status':'STUDENT', 'preferred_housing':'DORM'})
    return render_to_response('contact.html',{'form':form,
                              'user':request.user,
                              'request':request,},
                              context_instance=RequestContext(request))
