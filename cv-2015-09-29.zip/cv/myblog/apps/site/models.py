import datetime,pytz
from django.db import models
from django.contrib.auth.models import User
from django import forms
from django.template.defaultfilters import slugify
from django.db.models.signals import post_save,m2m_changed
import re


class ContactForm(forms.Form):
    name=forms.CharField(max_length=254,required=True)
    email=forms.EmailField(max_length=254, required=True)
    subject=forms.CharField(max_length=254, required=True)
    comments=forms.CharField(required=True,min_length=5,widget=forms.Textarea(attrs={'cols': 80, 'rows': 8}))
  
    def clean(self):
        super(ContactForm,self).clean()
        cd=self.cleaned_data
        #print 'cd', cd
        #if cd.has_key('expert_wanted') and cd.has_key('facillitator_is_expert'):
        #    if cd['facillitator_is_expert'] and cd['expert_wanted']:
        #        raise forms.ValidationError("If you are an expert, you cannot request an expert.  1 per group.  Sorry.")
        return cd

