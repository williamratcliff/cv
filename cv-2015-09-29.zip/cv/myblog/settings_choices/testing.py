from myblog.settings.development import *

