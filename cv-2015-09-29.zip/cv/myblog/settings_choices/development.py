from myblog.settings.base import *
#DATABASES['default']['NAME'] = 'myblog_development'

import os,sys

if sys.platform=='win32':
    #HOMEDIR=r'c:\dataflow_new'
    HOMEDIR=os.path.dirname(__file__)
    REPO_ROOT = os.path.split(HOMEDIR)[-1]
    #FILES_DIR = 
else:
    HOMEDIR = os.path.abspath(os.path.dirname(__file__))
    REPO_ROOT = os.path.basename(HOMEDIR)
    #FILES_DIR = '/var/www/FILES/'


DATABASES['default']['ENGINE']='django.db.backends.sqlite3'#, # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
DATABASES['default']['NAME']=os.path.join(HOMEDIR,'testdb')#,             # Or path to database file if using sqlite3.
