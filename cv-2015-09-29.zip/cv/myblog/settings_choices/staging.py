from myblog.settings.base import *
