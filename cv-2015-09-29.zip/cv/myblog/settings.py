from settings_choices.base import *
#DATABASES['default']['NAME'] = 'myblog_development'

import os,sys
MAINTENANCE_MODE = False 

if 1:
    DEBUG = True
    TEMPLATE_DEBUG = True
if 0:
    DEBUG = False
    TEMPLATE_DEBUG = False



if sys.platform=='win32':
    #HOMEDIR=r'c:\dataflow_new'
    HOMEDIR=os.path.dirname(__file__)
    REPO_ROOT = os.path.split(HOMEDIR)[-1]
    #FILES_DIR = 
else:
    HOMEDIR = os.path.abspath(os.path.dirname(__file__))
    REPO_ROOT = os.path.basename(HOMEDIR)
    #FILES_DIR = '/var/www/FILES/'


DATABASES['default']['ENGINE']='django.db.backends.sqlite3'#, # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
DATABASES['default']['NAME']=os.path.join(HOMEDIR,'testdb')#,             # Or path to database file if using sqlite3.



if 0:    
    EMAIL_USE_TLS = True
    EMAIL_HOST = 'smtp.gmail.com'
    EMAIL_HOST_USER = 'abecedarian314159@gmail.com'
    EMAIL_HOST_PASSWORD = r'lufe2o4*'
    EMAIL_PORT = 587
    DEFAULT_FROM_EMAIL = 'MyTest <abecedarian314159@gmail.com>'

if 1:
    EMAIL_USE_TLS= True
    EMAIL_HOST='smtp.webfaction.com'
    EMAIL_HOST_USER='williamblog'
    EMAIL_HOST_PASSWORD=r'lufe2o4*'
    EMAIL_PORT=587
    DEFAULT_FROM_EMAIL='WilliamRatcliff <support@williamratcliff.com>'
    SERVER_EMAIL='webmaster@williamratcliff.com'
